<?php
#define variables constantes de conexión
define('TIPO','mysqli');
define('SERVIDOR','localhost');
define('USUARIO','root');
define('PASSWORD','');
define('BASEDATOS','ventas');

?>
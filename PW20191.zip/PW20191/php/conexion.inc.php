<?php
#conexion a base de datos con ADODB.php
include '../lib/adodb5/adodb.inc.php';
include 'config.inc.php';

abstract class Conectar {
    private $conn;
    private $tipo=TIPO;
    private $servidor=SERVIDOR;
    private $usuario=USUARIO;
    private $password=PASSWORD;
    private $basedatos=BASEDATOS;
//CREAR METODO PARA CONECTAR 'CONEXION'
    public function conexion(){
        try{
            //crear capturas
            # negacion !
            # Conexion con el motor de base de datos
            if (!$this->conn=ADONewConnection($this->tipo)){
                throw new Exception('Error al conectarse a motor (driver)');
                
                
                }
                elseif(!$this->conn->Connect($this->servidor,$this->usuario,$this->password,$this->basedatos)){
                    throw new Exception('Error al conectarse a base de datos');
                    
                }
                return $this->conn; //devuelve la conexion 
            
            } catch(Exception $e){
                // mostrar capturas
                ?>
                <!-- seccion de HTML para mensajes-->
                <h3>Han ocurrido Error(es) <?php echo $e->getMessage();?></h3>
                <?php
                };
        
                
    } //FIN DE METODO CONEXION
    
    
    
}

?>
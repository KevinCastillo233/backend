<?php
$servidor="mysql:dbname=auto-service;localhost=127.0.0.1";
$usuarios="root";
$password="";

try{
    $pdo= new PDO($servidor,$usuarios,$password);
    //echo "Conectado..";
}catch(PDOException $e){
    echo "Conexion erronea".$e->getMessage();
    
}
//array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"
?>
<?php
/*
 *
 *Script para conectar MYSql
 *
 */

 $conn=mysqli_connect('localhost','root','','ventas')
 or die('Error en la conexion') ;
 $sqlClientes='SELECT rfc, nombre,direccion, correo, telefono FROM clientes'
 $qryClientes=mysqli_query($conn,$sqlClientes)
 or die('Error en consulta');;
 //tema de tabla
 ?>
 
 <table>
  <tr><td>RFC</td><td>Nombre</td><td>Direccion</td><td>Correo</td><td>Telefono</td></tr>
 </table>
 
 <?php
 if(mysqli_num_rows($qryClientes))
 { 
 while($renglon=mysqli_fetch_array($qryClientes))
 {
  ?>
  <tr><td><?php $renglon ['rfc']; ?></td>
  <td><?php $renglon ['nombre']; ?></td>
  <td><?php $renglon ['direccion']; ?></td>
  <td><?php $renglon ['correo']; ?></td>
  <td><?php $renglon ['telefono']; ?></td></tr>
  
  <?php
   echo 'Nombre',$renglon['nombre'].'Correo',$renglon['correo'];
    
 }//fin del while
}//fin del if
else
{
?>
<tr><td colspan="5">No hay registros</td></tr>
<?php
}
?>

<pre>
   <?php echo var_dump($sqlClientes);?>
</pre>
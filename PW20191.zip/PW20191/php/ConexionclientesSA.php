<?php
$servidor="mysql:dbname=auto-service;localhost=127.0.0.1";
$Usuarios="root";
$password="";

try{
    $pdo= new PDO($servidor,$Usuarios,$password);
   // echo "Conectado..";
}catch(PDOException $e){
    echo "Conexion erronea".$e->getMessage();
    
}
//array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES UTF8"
?>
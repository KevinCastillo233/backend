<?php
#aqui se den todas las acciones CRUD
include 'Conexion.inc.php';
ini_set('display_errors',0);
class Clientes extends Conectar{
    //TODO
    private $db;
    
    public function __construct(){
        $this->db=parent::conexion();
    }
    #metodo para consultar (R)
    public function listarClientes()
    {
        $this->db->SetFetchMode(ADODB_FETCH_ASSOC);
        $sqlClientes='SELECT rfc, nombre, direccion,correo, telefono FROM clientes';
        $rstClientes=$this->db->Execute($sqlClientes);
        #crear variables de regreso
        $aMensaje['exito']=false;
        $aMensaje['clientes']=[];
        //$aMensaje=['exito'=>false];
        #si hay usuarios crear extraccion del recordset
        $aClientes=[];
        if($rstClientes){
            $aMensaje['exito']=true;
            while(!$rstClientes->EOF){
                $aClientes[]=array(
                                   'rfc'=>$rstClientes->fields('rfc'),
                                   'nombre'=>$rstClientes->fields('nombre'),
                                   'direccion'=>$rstClientes->fields('direccion'),
                                   'correo'=>$rstClientes->fields('correo'),
                                   'telefono'=>$rstClientes->fields('telefono'));
                $rstClientes->MoveNext();
            }//fin del while
            $aMensaje['clientes']=$aClientes;
        }//fin del if
        return $aMensaje;
        //return $rstUsuarios;
    }
}

?>
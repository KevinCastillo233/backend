<?php
#aqui se den todas las acciones CRUD
include 'conexion.inc.php';
ini_set('display_errors',0);
class Usuarios extends Conectar{
    //TODO
    private $db;
    
    public function __construct(){
      session_start();
        $this->db=parent::conexion();
    }
    #metodo para consultar (R)
    public function listarUsuarios()
    {
        $this->db->SetFetchMode(ADODB_FETCH_ASSOC);
        $sqlUsuarios='SELECT id, nombre, correo, rol FROM usuarios';
        $rstUsuarios=$this->db->Execute($sqlUsuarios);
        #crear variables de regreso
        $aMensaje['exito']=false;
        $aMensaje['usuarios']=[];
        //$aMensaje=['exito'=>false];
        #si hay usuarios crear extraccion del recordset
        $aUsuarios=[];
        if($rstUsuarios){
            $aMensaje['exito']=true;
            while(!$rstUsuarios->EOF){
                $aUsuarios[]=array(
                                   'id'=>$rstUsuarios->fields('id'),
                                   'nombre'=>$rstUsuarios->fields('nombre'),
                                   'correo'=>$rstUsuarios->fields('correo'),
                                   'rol'=>$rstUsuarios->fields('rol'));
                $rstUsuarios->MoveNext();
            }//fin del while
            $aMensaje['usuarios']=$aUsuarios;
        }//fin del if
        return $aMensaje;
        //return $rstUsuarios;
    }//fin metodo listar
    
    #metodo agregarUsuario
    public function agregarUsuario($id,$nombre,$email,$password,$rol,$foto){
    $sqlUsuario="INSERT INTO usuarios (id, nombre, correo, password, rol, foto) VALUES ('$id','$nombre','$email','$password','$rol','$foto')";
    #crear variables de regreso
    
    $rstUsuario=$this->db->Execute($sqlUsuario);
    
    $aMensaje=[];
    $aMensaje['exito']=false;
    
    if($rstUsuario){
        $aMensaje['exito']=true;
    }
    return $aMensaje;
  
  
  
 
    
  }
  #metodo buscarUsuario
    public function buscarUsuario($id){
    $sqlUsuario="SELECT id, nombre, correo, rol FROM usuarios WHERE id='$id'";
    #crear variables de regreso
    $aMensaje=[];
    $aMensaje['exito']=false;
    $aMensaje['id']=false;
    
     $rstUsuario=$this->db->Execute($sqlUsuario);
    
    if($rstUsuario-> RecordCount()){
        $aMensaje['exito']=true;
    }
    return $aMensaje;

  }
  #metodo login
    public function login($id,$password){
      session_start();
    $sqlUsuario="SELECT id, nombre,rol FROM usuarios WHERE id='$id' AND password='$password'";
    #crear variables de regreso
    $aMensaje=[];
    $aMensaje['exito']=false;
        $this->db->SetFechMode(ADODB_FETCH_ASSOC);
            $rstUsuario=$this->db->Execute($sqlUsuario);
    if($rstUsuario-> RecordCount()){
        $aMensaje['exito']=true;
        //crear asociados en $_SESSION
        $_SESSION['rol']=$rstUsuario->fields('rol');
        $_SESSION['nombre']=$rstUsuario->fields('nombre');
         $_SESSION['token']='#$%^123a.';
    }
    else{
       $_SESSION['rol']=0;
        $_SESSION['nombre']='';
         $_SESSION['token']='';
      
    }
    return $aMensaje;
  }
} //fin de clase usuarios

?>
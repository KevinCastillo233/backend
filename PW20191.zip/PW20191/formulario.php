<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formularios</title>
</head>

<body>
    <form action="" method="get">
        <label>nombre</label>
        <input type="text" name="nombre"
        size="20" maxlengt="60" required="required">
        <select name="deportes">
            <option value="0" selected="selected">seleccione una opcion</option>
            <option value="1">futbol</option>
            <option value="2">basketbol</option>
        </select>
        <br>
        <label>Comentarios</label>
        <textarea name="cometarios">
            
        </textarea>      
        <label>edad</label>
        <input type="numer" name="edad"
        size="10" maxlengt="2" required="required">
        <label>Color de ojos</label>
        <input type="color" name="Color_ojos"
        size="10" required="required">
        <button type="submit">enviar</button>
    </form>
</body>

</html>
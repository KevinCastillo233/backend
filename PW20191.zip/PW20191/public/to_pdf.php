<?php
include '../php/UsuariosController.php';
include '../lib/fpdf/fpdf.php';
$usuarios=new Usuarios;
$listarUsuarios=$usuarios->listarUsuarios();
$pdf=new FPDF;
$pdf->AddPage();
$pdf->SetFont('arial','B',16);
$pdf->Image('assest/img/logos.png',10,10,20);
$pdf->SetFillColor(90,90,90);
$pdf->SetTextColor(255);
$pdf->SetXY(35,17.5);
$pdf->Cell(145,10,'Empresas S.A de C.V',1,1,'C',1);
$pdf->SetY(38);
$pdf->SetTextColor(0);
$pdf->Cell(180,7,'Listado de Usuarios',1,1,'C');
$pdf->Ln(2);
# encabezado
$pdf->SetFont('arial','B',12);
$pdf->Cell(20,5,'ID','LT',0,'C');
$pdf->Cell(60,5,'Nombre','LT',0,'C');
$pdf->Cell(80,5,'Correo','LT',0,'C');
$pdf->Cell(20,5,'Rol','LTR',1,'C');
$pdf->SetFont('arial','',10);
if($listarUsuarios['exito'])
{
foreach($listarUsuarios['usuarios'] as $key => $usuario){
$pdf->Cell(20,5,$usuario['id'],'LTB',0,'C');
$pdf->Cell(60,5, $usuario['nombre'],'LTB',0,'C');
$pdf->Cell(80,5, $usuario['correo'],'LTB',0,'C');
$pdf->Cell(20,5, $usuario['rol'],'LTBR',1,'C');

       
    }
    fclose($archivo_csv);
}
//echo json_encode($listarUsuarios['exito']);
$pdf->SetY(-30);
$pdf->Cell(180,5,'Derechos Reservados'.date(Y),0,0,'C');
$pdf->OutPut('usuarios'.time().'.pdf','I');
//$pdf->OutPut();
?>
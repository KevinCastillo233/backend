<?php
#INICIO DE SESION
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio</title>
    <!-- Zona de css-->
    <link rel="stylesheet" href="assest/css/bootstrap.min.css">
     <link rel="stylesheet" href="assest/css/font-awesome.min.css">
     <style>
     </style>
</head>
<body>
     <div class="container">
      <div class="row">
        <div class="col-sm-3">
          <img src="assest/img/ima.png" width="80px"alt="logo">
        </div>
        <div class="col-sm-9"><h1>Empresas S.A de C.V</h1></div>
      </div>
     </div>
       <div class="container-fluid"> 
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="index.php"><i class="fa fa-home fa-lg  rojo "></i></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="Clientes.php">Clientes <span class="sr-only">(current)</span></a>
      </li>
      <!--<li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>-->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Ventas
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Listar</a>
          <a class="dropdown-item" href="#">Exportar</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
             <!-- </li>
               <li class="nav-item">
               <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                </li>-->
     
    </ul>
     <ul class="navbar-navitem ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
        </li>
      </ul>
  </div>
</nav>
    </div> <!-- ./container menu-->
    <!-- Zona de despliegue-->
    <!-- Button trigger modal <button type="button" class="btn btn-primary"
    data-toggle="modal" data-target="#exampleModal">
    Launch demo modal
    </button>
       -->
    
       <?php
       if(isset($_SESSION['rol'])&& $_SESSION['rol']===1 && $_SESSION['token']==='#$%^123a.'){
       ?>
        <div class="container mt-2">
      <div class="row">
        <div class="col float-right"><a href="#addcliente" class="btn btn-primary" data-toggle="modal" >
  <i class="fa fa-plus fa-2x textwarning float-right"></i></a></div>
        </div>
    <table class="table table-sm table-striped table -hover table-bordered">
  <thead>
     <!--zona de despliegue-->
    <tr>
      <th scope="col">#</th>
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">correo Electr&oacute;nico</th>
       <th scope="col">Rol</th>
      <th>opciones</th>
    </tr>   
  </thead>
  <tbody id=usuarios>
  </tbody>
  <tfoot>
    <td>Exportar:</td>
    <td><button type="button" class="btn btn-info" title="Exportar a CSV" id="csv"> <i class="fa fa-file-excel-o"></i></button></td>
    <td><button type="button" class="btn btn-info" title="Exportar a XML" id="xml"> <i class="fa fa-file-code-o"></i></button></td>
    <td><button type="button" href= "to_pdf.php" target="_blank" class="btn btn-info" title="Exportar a PDF" id="pdf"> <i class="fa fa-file-pdf-o"></i></button></td>
  </tfoot>
</table>

        <?php
        }
        else{
        ?>
        <h1>No esta autorizado/a para la operaci&oacute;n</h1>
        <?php
        }
        ?>
          </div>
        
        <!--zona de ventanas modales-->
         <!--zona de ventana cliente-->
         <div class="modal" tabindex="-1" role="dialog" id=addcliente>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Registrar Cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
             
      <div class="container">
      <div class="row"></div>
      <div class="col-sm-5 col-sm-offset-3"></div>
      <div class="card text-center">
  <div class="card-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Registrarse</div>
  <div class="card-body">
    
    <!-- <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a> -->
   <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="rfc">R.F.C</label>
     </div>
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-male"></i> </div>
        </div>
        <input type="text" class="form-control" id="rfc1" placeholder="R.F.C">
      </div>
  </div>

  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="nombre">Nombre</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-child"></i> </div>
        </div>
        <input type="text" class="form-control" id="nombre1" placeholder="Nombre" maxlength=60>
      </div>
  </div>
  
  
  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="direccion">Direccion</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-address-card"></i> </div>
        </div>
        <input type="text" class="form-control" id="direccion1" placeholder="Direccion">
      </div>
  </div>
  
    
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="telefono">Telefono</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-phone"></i> </div>
        </div>
        <input type="number" class="form-control" id="telefono1" placeholder=Telefono>
      </div>
  </div>
  
  
  <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="correo">Correo</label>
    </div>
    
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-envelope"></i> </div>
        </div>
        <input type="text" class="form-control" id="correo1" placeholder="Correo" maxlength=100>
      </div>
  </div>

   </div>
       
  </div> 
    <hr>
  <button type="submit" class="btn btn-primary btn-lg btn-block"> <i class="fa fa-sign-in"></i>&nbsp;Registrar</button>
    </div>
 
  </div>
        <p>Modal body text goes here.</p>
      </div>
      
    </div>
  </div>
</div>
          <!--./zona de ventana registrar  cliente -->
          <!--zona de ventanas modales-->
         <!--zona de ventana ver cliente-->
         <div class="modal" tabindex="-1" role="dialog" id=vercliente>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Ver Cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
             
      <div class="container">
      <div class="row"></div>
      <div class="col-sm-5 col-sm-offset-3"></div>
      <div class="card text-center">
  <div class="card-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Registrarse</div>
  <div class="card-body">
    
    <!-- <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a> -->
   <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="rfc">R.F.C</label>
     </div>
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-male"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="R.F.C">
      </div>
  </div>

  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="nombre">Nombre</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-child"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Nombre" maxlength=60>
      </div>
  </div>
  
  
  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="direccion">Direccion</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-address-card"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Direccion">
      </div>
  </div>
  
    
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="telefono">Telefono</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-phone"></i> </div>
        </div>
        <input type="number" class="form-control" id="inlineFormInputGroupUsername" placeholder=Telefono>
      </div>
  </div>
  
  
  <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="correo">Correo</label>
    </div>
    
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-envelope"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Correo" maxlength=100>
      </div>
  </div>

   </div>
       
  </div> 
    <hr>
  <button type="submit" class="btn btn-primary btn-lg btn-block"> <i class="fa fa-sign-in"></i>&nbsp;Registrar</button>
    </div>
 
  </div>
        
      </div>
      
    </div>
  </div>
</div>
          <!--./zona de ventana ver cliente -->
          
          <!--zona de ventana modificar cliente-->
         <div class="modal" tabindex="-1" role="dialog" id=modcliente>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modificar Cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
             
      <div class="container">
      <div class="row"></div>
      <div class="col-sm-5 col-sm-offset-3"></div>
      <div class="card text-center">
  <div class="card-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Modificar Cliente</div>
  <div class="card-body">
    
    <!-- <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a> -->
   <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="rfc">R.F.C</label>
     </div>
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-male"></i> </div>
        </div>
        <input type="text" class="form-control" id="rfc2" placeholder="R.F.C">
      </div>
  </div>

  
  <form   action="" method="get" id="frmeditar">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="nombre">Nombre</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-child"></i> </div>
        </div>
        <input type="text" class="form-control" id="Nombre2" placeholder="Nombre" maxlength=60>
      </div>
  </div>
  
  
  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="direccion">Direccion</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-address-card"></i> </div>
        </div>
        <input type="text" class="form-control" id="direccion2" placeholder="Direccion">
      </div>
  </div>
  
    
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="telefono">Telefono</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-phone"></i> </div>
        </div>
        <input type="number" class="form-control" id="telefono2" placeholder=Telefono>
      </div>
  </div>
  
  
  <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="correo">Correo</label>
    </div>
    
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-envelope"></i> </div>
        </div>
        <input type="text" class="form-control" id="correo2" placeholder="Correo" maxlength=100>
      </div>
  </div>

   </div>
       
  </div> 
    <hr>
  <button type="submit" class="btn btn-primary btn-lg btn-block" id="btn_actualizar"> <i class="fa fa-sign-in"></i>&nbsp;Registrar</button>
    </div>
 
  </div>
        
      </div>
      
    </div>
  </div>
</div>
          <!--./zona de ventana eliminar cliente -->
          <!--zona de ventana modificar cliente-->
         <div class="modal" tabindex="-1" role="dialog" id=elicliente>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Eliminar Cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
             
      <div class="container">
      <div class="row"></div>
      <div class="col-sm-5 col-sm-offset-3"></div>
      <div class="card text-center">
  <div class="card-header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Eliminar Cliente</div>
  <div class="card-body">
    
    <!-- <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a> -->
   <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="rfc">R.F.C</label>
     </div>
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-male"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="R.F.C">
      </div>
  </div>

  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="nombre">Nombre</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-child"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Nombre" maxlength=60>
      </div>
  </div>
  
  
  
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="direccion">Direccion</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-address-card"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Direccion">
      </div>
  </div>
  
    
  <form   action="" method="get">
  <div class = "form-group"> 
  <div class="col-sm-1 col-sm-offset-3">
  <label for="telefono">Telefono</label>
  </div>
    
    <div class="input-group ">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-phone"></i> </div>
        </div>
        <input type="number" class="form-control" id="inlineFormInputGroupUsername" placeholder=Telefono>
      </div>
  </div>
  
  
  <form action="" method="get">
  <div class="form-group">
    <div class="col-sm-1 col-sm-offset-3">
    <label for="correo">Correo</label>
    </div>
    
    <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"> <i class="fa fa-envelope"></i> </div>
        </div>
        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Correo" maxlength=100>
      </div>
  </div>
   </div>   
  </div> 
    <hr>
  <button type="submit" class="btn btn-primary btn-lg btn-block"> <i class="fa fa-sign-in"></i>&nbsp;Eliminar</button>
    </div>
  </div>  
      </div>
    </div>
  </div>
</div>
          <!--./zona de ventana eliminar cliente -->     
         <!--./zona de ventanas modales-->   
    <!--./zona de despliegue-->
    <!-- Zona de js-->
    <script src="assest/js/jquery.js"></script>
    <script src="assest/js/bootstrap.min.js"></script>
       <script>
       $(function(){
        $.ajaxSetup({ cache:false});
                    $.getJSON('listarUsuarios.php', function(datos){
                       //console.log(datos);
                       $.each(datos.usuarios,function(indice,usuario){
                        // ARMAR LA TABLA 
                            $('#usuarios').append('<tr><td>'+(indice+1)+
                            '</td><td>'+usuario.id+
                            '</td><td>'+usuario.nombre+
                            '</td><td>'+usuario.correo+
                            '</td><td>'+usuario.rol+
                            '</td><td>  <a href="#editusuario" class="btn btn-warning btn-sm" data-toggle="modal" id="btn_Editar" data-id="'+usuario.id+'"data-nombre="'+usuario.nombre+'"data-correo="'+usuario.correo+'"data-rol="'+usuario.rol+'"><i class="fa fa-edit"></i>  &nbsp</a>&nbsp  <a href="#verusuario" class="btn btn-info btn-sm" data-toggle="modal" id="btn_ver"><i class="fa fa-eye"></i> &nbsp</a>&nbsp<a href="#elicliente" class="btn btn-danger btn-sm" data-toggle="modal" id="btn_borrar"><i class="fa fa-trash"></i> &nbsp</a> </td></tr>');
                            
                        //console.log(indice,cliente);
                        });
                       })
                    . fail (function(e){ console.log(e.responseText);
                            });//fin get JSON
                    $('#editusuario').on('shown.bs.modal',function(evt){
                      evt.preventDefault();
                      var aUsuario=$(evt.relatedTarget);
                      $('#usuario2').val(aUsuario.data('id'));
                      $('#nombre2').val(aClientes.data('nombre'));
                      $('#correo2').val(aClientes.data('correo'));
                      $('#rol2').val(aClientes.data('rol'));
                    
                      });
                    //llamar ventana modal y mostrar datos
                    //function para actualizar
                    $('#btn_actualizar').on('click',function(){
                      //poner codigo para actualizar
                      //primero validar
                      //var datos=$('#frmeditar').serialize();
                      var oFrm=$('#frmeditar')[0];
                      var datos= new FormData(oFrm); 
                      //console.log(datos);
                      //alert('acciones futuras');
                      $.ajax({
                        url:'actualizar.php',
                        type:'POST',
                        dataType:'json',
                        data:datos,
                        //como se sta usando FormData
                        enctype:'multipart/form-data',
                        processData:false,//evita inyeccion de codigo sql
                        contentType:false,
                        cache:false  
                      })
                      .done(function(respuesta){
                        //TODO...
                       if(respuesta.exito){
                        
                       }
                        })
                      .fail(function(e){
                        console.log(e.responseText);
                        });//fin de ajax
                      });
                    //crear CSV
                    $('#csv').on('click',function(){
                      $.ajax({
                        type:'GET',
                        url:'to_csv.php',
                        dataType:'json'
                        })
                      .done(function(respuesta){
                        if(respuesta){
                          alert('Archivo creado con exito');
                        }   
                      })
                      .fail(function(e){
                        console.log(e.responseText);
                        });
                      });
       
         //por el momento evitar usar llamada AJAX con creación PDF
        //crear XML
                   $('#xml').on('click',function(){
                      $.ajax({
                        type:'GET',
                        url:'to_xml.php',
                        dataType:'json'
                        })
                      .done(function(respuesta){
                        if(respuesta){
                          alert('Archivo creado con exito');
                          //location.href="usuarios.php";
                        }   
                      })
                      .fail(function(e){
                        console.log(e.responseText);
                        });
                      });
                   
            });//fin de carga de pagina
    </script>
    
        
    
    
</body>

</html>

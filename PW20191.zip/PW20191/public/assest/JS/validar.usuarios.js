		$.validator.setDefaults( {
			submitHandler: function () {
           var oFrm=$('#frmUsuario')[0];
           var datos=new FormData(oFrm);
           //console.log(datos);
           //alert('Acciones Futuras');
           $.ajax({
            url:'script.php',//pendiente
            type:'POST',
            dataType:'json',//es la respuesta
            data:datos,
            //como se esta usando FormData
            enctype:'multipart/form-data',
            processData:false,
            contentType:false,
            cache:false
           });
            done(function(respuesta){
             console.log(respuesta);
             })
           .fail(function(e){
            console.log(e.responseText);
           });//fin de AJAX
			}
		} );

		$( document ).ready( function () {
			$( "#frmUsuario" ).validate( {
				rules: {
					
			id: {
                        required:true,
                        minlength: 1,
                        maxlength: 5
                        },
                        
			usuario: {
                        required:true,
                        minlength: 5,
                        maxlength: 20,
                        },
                        
                        password: {
                        required:true,
                        minlength: 8,
                        maxlength: 60,
                        pattern:/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/
                        },
                        
                        passwordConfirm: {
                        required:true,
			minlength: 8,
                        maxlength: 60,
			equalTo: "#password"
                        },
					
			rol: {
			required: true,
			minlength: 1,
                        maxlength: 3
			},
					
			},
			
			messages: {
			telefono:{
                            pattern:"minimo 3, maximo 12 digitos" 
                        }
				},
					
				errorElement: "em",
				errorPlacement: function ( error, element ) {
					// Add the `invalid-feedback` class to the error element
					error.addClass( "invalid-feedback" );

					if ( element.prop( "type" ) === "checkbox" ) {
						error.insertAfter( element.next( "label" ) );
					} else {
						error.insertAfter( element );
					}
				},
				highlight: function ( element, errorClass, validClass ) {
					$( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
				},
				unhighlight: function (element, errorClass, validClass) {
					$( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
				}
			} );

		} );
	
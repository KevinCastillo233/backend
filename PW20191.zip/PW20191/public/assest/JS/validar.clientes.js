
		$.validator.setDefaults( {
			submitHandler: function () {
				    var oFrm=$('#frmeditar')[0];
                    var datos=new FormData(oFrm);
                    //console.log(datos);
                    //alert('Acciones futuras');
                    $.ajax({
                     url:'script.php',//pendiente
                     type:'POST',
                     dataType:'json',
                     data:datos,
                     //como se esta usando FormData
                     encrypte: 'multipart/form-data',
                    processData:false,//evitar inyeccion de codigo SQL
                    contentType:false,
                     cache:false                                                         
                    })
                    .done(function(respuesta){
                     console.log(respuesta);
                    })
                    .fail(function(e){
                     console.log(e.responseText);
                     });//fin de ajax
                    
			}
		} );

		$( function () {
			$( "#frmeditar" ).validate( {
				rules: {
				rfc:{
                    required: true,
                    minlength: 12,
                    maxlength: 13
		    //pattern:
                    },
				nombre: { 
					required: true,
                    minlength: 2,
                    maxlength: 60,
                   
                },
                direccion: { 
					required: true,
                    minlength: 2,
                    maxlength: 60,
                   
                    },
                    
                telefono: { 
					required: true,
                    pattern:/^[0-9-()+]{3,12}$/
                    
                    },
					correo: {
						required: true,
						email: true
					},
					
				},
				messages: {
					telefono:{
                        pattern:"minimo3, maximo 12 numeros"
                    }
				},
				errorElement: "em",
				errorPlacement: function ( error, element ) {
					// Add the `invalid-feedback` class to the error element
					error.addClass( "invalid-feedback" );

					if ( element.prop( "type" ) === "checkbox" ) {
						error.insertAfter( element.next( "label" ) );
					} else {
						error.insertAfter( element );
					}
				},
				highlight: function ( element, errorClass, validClass ) {
					$( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
				},
				unhighlight: function (element, errorClass, validClass) {
					$( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
				}
			} );

		} );

<?php
    // Datos de la base de datos.
    $servidor="pw2019.com";
    $usuarioBD="root";
    $passwordBD="";	
    $baseDatos="auto-service";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="assest/css/imagen.css">
    <!--<link rel="stylesheet" type="text/css" href="assest/css/estilo-login.css" media="screen"/>-->    
    <script src="assest/js/jquery-1.7.2.min.js" type="text/javascript"></script> 
    <script src="assest/js/validarFormularios.js" type="text/javascript"></script>
    <link rel="stylesheet" href="assest/css/imagen.css">
    <link rel="stylesheet" href="assest/css/bootstrap.min.css">
    <link rel="stylesheet" href="assest/css/font-awesome.min.css">
    
    <title>Registro</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-sm-4 offset-sm-3">
                <div class="card">
                  <div class="card-header">
                    <!--ENCABEZADO-->
                    
                    RESGISTRARSE&nbsp;<i class=""></i>
                  </div>
                  <div class="card-body">
    <?php
   // assest/css/bootstrap.min.css
        require_once 'assest/controlador/config.php';
        require 'assest/modelo/usuario.php';
        require 'assest/controlador/GestorUsuarios.php';
        
        // Inicializamos las varibles que se usaran para los campos de texto del formulario.
        $usuario="";
        $email="";
        $nombre="";
        $apellidos="";
        $edad="";
        $telefono=""; 
        $password="";
        $password2="";

        if(isset($_POST['registrar'])){             
            $conexion = new mysqli($servidor, $usuarioBD, $passwordBD, $baseDatos);
            $nuevoUsuario = new Usuario($_POST['usuario'],$_POST['nombre'],
                                        $_POST['apellidos'],$_POST['email'],$_POST['edad'],$_POST['telefono'],
                                        $_POST['password'],$_POST['password2']);
            $gestor = new GestorUsuarios($conexion);    
            
            // Si todos los campos del usuario son correctos y se realiza la insercion del usuario con exito
            // se redireciona a la pagina correspondiente.
            if (($gestor->validarUsuario($nuevoUsuario)) && ($gestor->insertarUsuario($nuevoUsuario))) {
                $conexion->close();
                header("Location:formulario_login.php");
            }
            else{
                // Si algo falla se recuperan los datos introducidos por el usuario
                // para que no tenga que reescribir los que estuviesen correctos.
                $usuario=$_POST['usuario'];
                $email=$_POST['email'];
                $nombre=$_POST['nombre'];
                $apellidos=$_POST['apellidos'];
                $edad=$_POST['edad'];
                $telefono=$_POST['telefono']; 
                $password=$_POST['password'];
                $password2=$_POST['password2']; 
            }
        }
    ?>
    <section>
        <div id="formulario_registro">
            <form action="#" method=POST>
                <div class="campoFormulario">
                    <label for="usuario">Usuario: <span class="obligatorio">*</span></label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-user"></i></div>
                    <input type='text' id="usuario" name="usuario" maxlength="15"
                           value="<?php echo $usuario ?>" onblur="return validarNombreUsuario(this.value)" autocomplete="off"/>
                </div>
                <div class="campoFormulario">
                    <label for="password">Contraseña: <span class="obligatorio">*</span></label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-lock"></i></div>
                    <input type='password' id="password" name="password" maxlength="20"
                           value="<?php echo $password ?>" onblur="return validarPassword(this.value)" autocomplete="off"/>
                </div>
                <div class="campoFormulario">
                    <label for="password2">Repita la Contraseña: <span class="obligatorio">*</span></label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-check"></i></div>
                    <input type='password' id="password2" name="password2" maxlength="20"
                           value="<?php echo $password2 ?>" onblur="return validarPasswordIguales(password.value,this.value)"/>
                </div>
                <div class="campoFormulario">
                    <label for="email">Email: <span class="obligatorio">*</span></label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-envelope"></i></div>
                    <input type='text' id="email" name="email" maxlength="30"
                           value="<?php echo $email ?>" onblur="return validarEmail(this.value)"/>
                </div>
                <div class="campoFormulario">
                    <label for="nombre">Nombre:</label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-user"></i></div>
                    <input type='text' id="nombre" name="nombre" maxlength="20"
                           value="<?php echo $nombre ?>" onblur="return validarNombre(this.value)"/>
                </div>
                <div class="campoFormulario">
                    <label for="apellidos">Apellidos:</label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-user"></i></div>
                    <input type='text' id="apellidos" name="apellidos" maxlength="30"
                           value="<?php echo $apellidos ?>" onblur="return validarApellidos(this.value)"/>
                </div>
                <div class="campoFormulario">
                    <label for="edad">Edad:</label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-user"></i></div>
                    <input type='text' id="edad" name="edad" maxlength="30"
                           value="<?php echo $edad ?>" onblur="return validarEdad(this.value)"/>
                </div>
                <div class="campoFormulario">
                    <label for="telefono">Telefono: <span class="obligatorio">*</span></label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-phone"></i></div>
                    <input type='text' id="telefono" name="telefono" maxlength="10"
                           value="<?php echo $telefono ?>" onblur="return validarTelefono(this.value)"/>
                </div>


                <div class="botonFormulario">
                    <input type="submit" id="registrar" name="registrar" value="Registrarse">
                </div>  
            </form> 
        </div>
    </section>
</body>
</html>
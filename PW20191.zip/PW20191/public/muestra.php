<?php
#consultar en php.net

if(isset($_GET['nombre'])){
//echo "El valor es $_GET[nombre]";
    print_r($_GET);
}


?>
<pre>
    <?php echo var_dump($_GET); ?>
</pre>


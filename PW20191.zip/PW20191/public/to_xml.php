<?php
include '../php/UsuariosController.php';
$usuarios=new Usuarios;
$listarUsuarios=$usuarios->listarUsuarios();
if($listarUsuarios['exito'])
{
    // fopen crear/usar el archivo
    // frwite escribir en el archivo
    // fclose cerrar el archivo
    $archivo_xml=fopen('../archivos/usuarios.csv'.time().'.xml','w+');
    fwrite($archivo_xml, "<?xml version="1.0" encoding="UTF-8"?>\n<usuarios>\n>");
    foreach($listarUsuarios['usuarios'] as $key => $usuario){
        fwrite($archivo_xml,"<usuario\n<id>".
               $usuario['id']."</id>\n<nombre>".$usuario['nombre']."/nombre\n<correo>".
               $usuario['correo']."</correo\n<rol>". $usuario['rol']."</rol>\n</usuario>\n");
        
        
        
    }
    fwrite($archivo_xml,"</usuarios>");
    fclose($archivo_csv);
}
echo json_encode($listarUsuarios['exito']);
?>
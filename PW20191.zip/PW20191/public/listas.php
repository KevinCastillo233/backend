<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>listas</title>
</head>

<body>
    <ul>
        <li>uno</li>
        <ol>
        <li>uno</li>
        <li>dos</li>
    </ol>
        <li>dos</li>
    </ul>
    <ol>
        <li>uno</li>
        <li>dos</li>
        <ul>
        <li>uno</li>
        <ol>
        <li>uno</li>
        <li>dos</li>
    </ol>
        <li>dos</li>
    </ul>
    </ol>
</body>

</html>
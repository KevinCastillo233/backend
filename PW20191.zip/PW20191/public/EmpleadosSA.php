<?php
//sin modal
$txtID=(isset($_POST['txtID']))?$_POST['txtID']:"";
$txtNombre=(isset($_POST['txtNombre']))?$_POST['txtNombre']:"";
$txtApellidoPaterno=(isset($_POST['txtApellidoPaterno']))?$_POST['txtApellidoPaterno']:"";
$txtApellidoMaterno=(isset($_POST['txtApellidoMaterno']))?$_POST['txtApellidoMaterno']:"";
$txtDireccion=(isset($_POST['txtDireccion']))?$_POST['txtDireccion']:"";
$txtTelefono=(isset($_POST['txtTelefono']))?$_POST['txtTelefono']:"";
$txtTurno=(isset($_POST['txtTurno']))?$_POST['txtTurno']:"";
$txtDescanso=(isset($_POST['txtDescanso']))?$_POST['txtDescanso']:"";


$accion=(isset($_POST['accion']))?$_POST['accion']:"";

$error=array();

$accionAgregar="";
$accionModificar=$accionEliminar=$accionCancelar="disabled";
$mostrarModal=false;

include ("../php/ConexionempleadosSA.php");
//include ("ConexionserviciosSA.php");

switch($accion){
    
    case "btnAgregar":
        
        $sentencia=$pdo->prepare("INSERT INTO empleados(Nombre,ApellidoPaterno,ApellidoMaterno,Direccion,Telefono,Turno,Descanso)
        VALUES (:Nombre,:ApellidoPaterno,:ApellidoMaterno,:Direccion,:Telefono,:Turno,:Descanso) ");
        
        $sentencia->bindParam(':Nombre',$txtNombre);
        $sentencia->bindParam(':ApellidoPaterno',$txtApellidoPaterno);
        $sentencia->bindParam(':ApellidoMaterno',$txtApellidoMaterno);
        $sentencia->bindParam(':Direccion',$txtDireccion);
        $sentencia->bindParam(':Telefono',$txtTelefono);
        $sentencia->bindParam(':Turno',$txtTurno);
        $sentencia->bindParam(':Descanso',$txtDescanso);
        $sentencia->execute();
        //echo $txtID;
       // echo  "Presionaste btnAgregar";
        header('Location: EmpleadosSA.php');
        break;
        case "btnModificar":
             $sentencia=$pdo->prepare(" UPDATE empleados SET
                                     Nombre=:Nombre,
                                     ApellidoPaterno=:ApellidoPaterno,
                                     ApellidoMaterno=:ApellidoMaterno,
                                     Direccion=:Direccion,
                                     Telefono=:Telefono,
                                     Turno=:Turno,
                                     Descanso=:Descanso WHERE
                                     ID=:ID");
        
        $sentencia->bindParam(':Nombre',$txtNombre);
        $sentencia->bindParam(':ApellidoPaterno',$txtApellidoPaterno);
        $sentencia->bindParam(':ApellidoMaterno',$txtApellidoMaterno);
        $sentencia->bindParam(':Direccion',$txtDireccion);
        $sentencia->bindParam(':Telefono',$txtTelefono);
        $sentencia->bindParam(':Turno',$txtTurno);
        $sentencia->bindParam(':Descanso',$txtDescanso);
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        
        header('Location: EmpleadosSA.php');// redirecionamiento donde queremos que se valla la pagina
            //echo $txtID;
       // echo  "Presionaste btnModificar";
        break;
        case "btnEliminar":
             $sentencia=$pdo->prepare(" DELETE FROM empleados WHERE ID=:ID");
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        
        header('Location: EmpleadosSA.php');
            //echo $txtID;
       // echo  "Presionaste btnEliminar";
        break;
        case "btnCancelar":
            //echo $txtID;
       // echo  "Presionaste btnCancelar";
        header('Location: EmpleadosSA.php');
        break;
        case "Seleccionar":
            $accionAgregar="disabled";
            $accionModificar=$accionEliminar=$accionCancelar="";
            $mostrarModal=true;
                 
        $sentencia=$pdo->prepare(" SELECT * FROM `empleados` WHERE
                                     ID=:ID");
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        $empleados=$sentencia->fetch(PDO::FETCH_LAZY);
        
        $txtNombre=$empleados['Nombre'];
        $txtApellidoPaterno=$empleados['ApellidoPaterno'];
        $txtApellidoMaterno=$empleados['ApellidoMaterno'];
        $txtDireccion=$empleados['Direccion'];
        $txtTelefono=$empleados['Telefono'];
        $txtTurno=$empleados['Turno'];
        $txtDescanso=$empleados['Descanso'];
        
        break;
    
        
    
}
 
$sentencia= $pdo->prepare("SELECT * FROM `empleados` WHERE 1");
$sentencia->execute();
$listaempleados=$sentencia->fetchAll(PDO::FETCH_ASSOC);

//print_r($listaclientes);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro De Empleados</title>
    
    <link rel="stylesheet" href="assest/css/imagen.css">
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>

<body>
		
    <div>
        <form action="" method="post" enctype="multipart/form-data">

<section class="principal">
    <h1>Auto Service</h1>
<div class="form-1-2">
    <label for="caja_busqueda">Buscar</label>
    <input type="text" name="caja_busqueda" id="caja_busqueda"></input>
    
</div>

<div id="datos">
    
</div>
</section>
<script src="assest/js/jquery.min.js"></script>
<script src="assest/js/main.js"></script>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Registro De Empleados</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
            <input type="hidden" required name="txtID" value="<?php echo $txtID;?>" placeholder="" id="txtID" require="">

<div class="form-group col-md-6">
<label for="">Nombre(s):</label>
<input type="text" class="form-control" <?php echo (isset($error['Nombre']))?"is-invalid":"";?> name="txtNombre" required value="<?php echo $txtNombre;?>" placeholder="" id="txtNombre" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Nombre']))?$error['Nombre']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Apellido Paterno:</label>
<input type="text" class="form-control" <?php echo (isset($error['ApellidoPaterno']))?"is-invalid":"";?> name="txtApellidoPaterno" required value="<?php echo $txtApellidoPaterno;?>" placeholder="" id="txtApellidoPaterno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['ApellidoPaterno']))?$error['ApellidoPaterno']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Apellido Materno:</label>
<input type="text" class="form-control" <?php echo (isset($error['ApellidoMaterno']))?"is-invalid":"";?> name="txtApellidoMaterno" required value="<?php echo $txtApellidoMaterno;?>" placeholder="" id="txtApellidoMaterno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['ApellidoMaterno']))?$error['ApellidoMaterno']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Direccion:</label>
<input type="text" class="form-control" <?php echo (isset($error['Direccion']))?"is-invalid":"";?> name="txtDireccion" required value="<?php echo $txtDireccion;?>" placeholder="" id="txtDireccion" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Direccion']))?$error['Direccion']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Telefono:</label>
<input type="text" class="form-control" <?php echo (isset($error['Telefono']))?"is-invalid":"";?> name="txtTelefono" required value="<?php echo $txtTelefono;?>" placeholder="" id="txtTelefono" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Telefono']))?$error['Telefono']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Turno:</label>
<input type="text" class="form-control" <?php echo (isset($error['Turno']))?"is-invalid":"";?> name="txtTurno" value="<?php echo $txtTurno;?>" placeholder="" id="txtTurno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Turno']))?$error['Turno']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Descanso:</label>
<input type="text" class="form-control" <?php echo (isset($error['Descanso']))?"is-invalid":"";?> name="txtDescanso" value="<?php echo $txtDescanso;?>" placeholder="" id="txtDescanso" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Descanso']))?$error['Descanso']:"";?>
</div>
<br>
</div>

        </div>
      </div>
      <div class="modal-footer">
           <!-- creacion de botones  -->
<button value="btnAgregar" <?php echo $accionAgregar;?> class="btn btn-success" type="submit" name="accion">Agregar</button>
<button value="btnModificar" <?php echo $accionModificar;?> class="btn btn-warning" type="submit" name="accion">Modificar</button>
<button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" <?php echo $accionEliminar;?> class="btn btn-danger" type="submit" name="accion">Eliminar</button>
<button value="btnCancelar" <?php echo $accionCancelar;?> class="btn btn-primary" type="submit" name="accion">Cancelar</button>
      </div>
    </div>
  </div>
</div>
</div>

            <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Agegar Empleado
</button>
<br>
<br>
        </form>
        <div class="row">
            <table class="table table-hover table-borderred" bgcolor= "#ADBF87" border="2" cellpadding="1" cellspacing="1">
                <thead class="thead-dark">
                    <tr>
                       <th>ID</th>
                       <th>Nombre(s)</th>
                       <th>Apellido Paterno</th>
                       <th>Apellido Materno</th>
                       <th>Direccion</th>
                       <th>Telefono</th>
                       <th>Turno</th>
                       <th>Descanso</th>
                       <th>Acciones</th>
                    </tr>
                </thead>
                <?php foreach($listaempleados as $empleados){ ?>
                
                <tr>
                    <td><?php echo  $empleados['ID']; ?></td>
                    <td><?php echo  $empleados['Nombre']; ?></td>
                    <td><?php echo  $empleados['ApellidoPaterno']; ?></td>
                    <td><?php echo  $empleados['ApellidoMaterno']; ?></td>
                    <td><?php echo  $empleados['Direccion']; ?></td>
                    <td><?php echo  $empleados['Telefono']; ?></td>
                    <td><?php echo  $empleados['Turno']; ?></td>
                    <td><?php echo  $empleados['Descanso']; ?></td>
                    <td>
                    <form action="" method="post">
                        
                        <input type="hidden" name="txtID" value="<?php echo $empleados['ID'];?>">
                        <input type="submit" value="Seleccionar" class="btn btn-info" name="accion">
                        <button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" type="submit" class="btn btn-danger" name="accion">Eliminar</button>
                        
                    </form>
                    </td>
                </tr>
                <?php } ?>
            </table>   
        </div>
      <?php if($mostrarModal){?>
      <script>
        $('#exampleModal').modal('show');
      </script>
      <?php }?>
      <script>
        function Confirmar(Mensaje){
            return (confirm(Mensaje))?true:false;
        }
      </script>
    </div>
</body>
</html>
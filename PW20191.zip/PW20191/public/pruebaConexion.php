<link href="assest/css/bootstrap.min.css" rel=""
<?php
include '../php/UsuariosController.php';
$usuarios=new Usuarios;
$listarUsuarios=$usuarios->listarUsuarios();
?>
<table class="table table-striped">
    <tr><th>Sec.</th><th>id</th><th>Nombre</th><th>Correo</th><th>Rol</th></tr>
<?php
if($listarUsuarios['exito']){
    //echo $listarUsuarios['exito'];
  foreach($listarUsuarios['usuarios'] as $llave=>$valor){
    ?>
    <tr><td> <?php echo ($llave+1);?> </td>
    <?php
    foreach($valor as $key=>$usuario){
        ?>
        <td><?php echo $usuario; ?></td>
    
        
        <?php
    } // fin de foreach usuario
    ?>
    </tr>
    <?php
    
}// fin de forech usuarios
}//in del if
else {
    ?>
<tr><td colspan='5'></tdcolspan='5'></td></tr>'NO HAY REGISTROS';
    <?php
}

?>
</table>
<!--
<pre>
    <?php //echo var_dump($listarUsuarios);
    ?>
</pre>
-->
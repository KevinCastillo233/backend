<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Inicio</title>
<link rel="stylesheet" href="assest/css/bootstrap.min.css">
<link rel="stylesheet" href="assest/css/font-awesome.min.css">


<!--CSS ZONE-->
<style>
    .rojo {color:#f00;}
    .casino7, .casinobar, .casinocherry, .casinowin
{ background: url('assest/pictures/sprite.png') no-repeat; }

.casino7 { background-position: -0px -0px; width: 225px; height: 225px; }
.casinobar { background-position: -225px -0px; width: 225px; height: 225px; }
.casinocherry { background-position: -0px -225px; width: 225px; height: 225px; }
.casinowin { background-position: -225px -225px; width: 225px; height: 225px; }
</style>
</head>




<body>

<div class="container"> <!-- ./ encabezado -->
<div class="row">
  <div class="col-sm-3">
    <img src="assest/img/ima.png" alt="assest/img/ima.png" width=100px height=60px>
  </div>
  <div class="col-sm-9">
    <h1>Empresas S.A. de C.V.</h1>
  </div>
</div>
</div>
<hr>
<!-- ./ encabezado -->
<div class="container-fluid">
<nav class="navbar navbar-expand-lg navbar-dark bg-info ">
<a class="navbar-brand" href="index.html"><i class="fa fa-home fa-lg rojo "></i></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
  <li class="nav-item">
    <a class="nav-link" href="clientes.php">Clientes <span class="sr-only">(actual)</span></a>
  </li>
  <!--
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>-->
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Ventas
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="#">Listar</a>
      <a class="dropdown-item" href="#">Exportar</a>
      <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="#">Something else here</a>
    </div>
  </li>
  <!--
  <li class="nav-item">
    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
  </li>
  -->
  
  
</ul>
<ul class="navbar-nav ml-auto">
  <li class="nav-item ">
    <a class="nav-link" href="login.php">Login</a>
    </li>
  </ul>
<ul class="navbar-nav">
  <li class="nav-item active">
    
    </li>
  </ul>
<!--
<form class="form-inline my-2 my-lg-0">
  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
  <button class="btn btn-outline-success my-2 my-sm-0 btn-dark"  type="submit">Search</button>
</form>-->
</div>
</nav>
</div>



<!-- ./ container menu-->
<!--Zona de despliegue-->
<br>
<div class="container">
  <div class="row">
    <div class="col-sm-6 offset-sm-3"><div class="card text-center">
<div class="card-header">
Registro&nbsp;<i class="fa fa-key float-right"></i>
</div>
<div class="card-body">
<form action="agregarUsuario.php" method="POST"> 
<div class="form-group">
  <label for="id">ID</label>
  
  <div class="input-group"> 
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-barcode"></i></div>
    </div>
    <input type="text" class="form-control" maxlength="15" required="required" id="id" name="id" aria-describedby="id" placeholder="Introduzca un ID">
  </div>
  </div>


<div class="form-group">
  <label for="usuario">Usuario</label>    
  <div class="input-group"> 
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-user-circle"></i></div>
    </div>
  <input type="text" class="form-control" maxlength="60" required="required" id="usuario" name="usuario" aria-describedby="usuario" placeholder="Introduzca un nombre de usuario.">
  </div>
  </div>

<div class="form-group">
  <label for="password">Contraseña</label>
  <div class="input-group">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-lock"></i></div>
    </div>
  <input type="password" class="form-control" id="password" maxlength="60" required="required" name="password" aria-describedby="password" placeholder="Introduzca una contraseña.">
  </div>
  </div>

<div class="form-group">
  <label for="confirmarPassword">Confirmar contraseña</label>
  <div class="input-group">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-lock"></i></div>
    </div>
  <input type="password" class="form-control" id="confirmarPassword" maxlength="60" required="required" name="confirmarPassword" aria-describedby="confirmarPassword" placeholder="Vuelva a introducir la contraseña.">
  </div>
  </div>

<div class="form-group">
  <label for="rol">Rol</label>
  <div class="input-group">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-id-card"></i></div>
    </div>
  <input type="text" class="form-control" id="rol" maxlength="60" required="required" name="rol" aria-describedby="rol" placeholder="Introduzca su rol.">
  </div>
  </div>

 <div class="form-group">
    <label for="foto">Foto</label>
    <input type="file" class="form-control-file" id="foto"name="foto">
    
  </div>


    <button type="submit" class="btn btn-primary btn-lg btn-block"><i class="fa fa-sign-in"></i>&nbsp;Registrar</button>
    
</form>






 </div>
<div class="card-footer text-muted">
Derechos reservados
</div>
 
  
</div></div></div></div>


<!-- ./Zona de despliegue-->



<!--Zona de JS-->
    <script src="assest/js/jquery-3.3.1.min.js"></script>
    <script src="assest/js/bootstrap.min.js"></script>
    <!-- Validation -->
  <script src="assest/js/dist/jquery.validate.min.js"></script>
    <script src="assest/js/dist/additional-methods.min.js"></script>
    <script src="assest/js/dist/localization/messages_es.js"></script>
    <!--Validar Clientes-->
    <script src="assest/js/validar.usuarios.js"></script>
    
    
    
    
    
    <script>
     $(function(){
          $.ajaxSetup({ cache:false});
          //function para actualizar
          $('btnActualizar').on('click',function(){
           //Poner codigo para Actualizar
           //primero validar datos
           //Para el caso de subir "Files"
           //var datos=$('#frmUsuario').seralize();
           var oFrm=$('#frmUsuario')[0];
           var datos=new FormData(oFrm);
           //console.log(datos);
           //alert('Acciones Futuras');
           $.ajax({
            url:'script.php',//pendiente
            type:'POST',
            dataType:'json',//es la respuesta
            data:datos,
            //como se esta usando FormData
            enctype:'multipart/form-data',
            processData:false,
            contentType:false,
            cache:false
           });
            done(function(respuesta){
             console.log(respuesta);
             })
           .fail(function(e){
            console.log(e.responseText);
           });//fin de AJAX
           
           
           
           });
        //funciones para actualizar
        });//fin de la carga
     //inicio de existencia
     $(function(){
      $('#usuario').on('blur',function(){
       var id=$(this).val(); //var id=$('#usuario').val();
       $.ajax({
        type:'POST',
        url:'buscar.php',
        dataType:'json',
        data:'id='+id })
       .done(function(respuesta){
        // para debug/comprension
       //console.log(respuesta);
         if (respuesta.exito){
          // TODO
          alert('Ya existe');
          $('#usuario').select(); //focus();
         }
         else {
          //TODO
           $('#nombre').focus();
         }
        })
       .fail(function(e){
        console.log(e.responseText);
        });
       
       });
      
      });
     
    </script>



</body>

</html>
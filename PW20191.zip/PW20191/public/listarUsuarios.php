<?php
include '../php/UsuariosController.php';
$usuarios=new Usuarios;
$listarUsuarios=$usuarios->listarUsuarios();

echo json_encode($listarUsuarios);
?>
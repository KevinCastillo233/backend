<?php
$txtServicio=(isset($_POST['txtServicio']))?$_POST['txtServicio']:"";
$txtTipoDeServicio=(isset($_POST['txtTipoDeServicio']))?$_POST['txtTipoDeServicio']:"";
$txtCliente=(isset($_POST['txtCliente']))?$_POST['txtCliente']:"";
$txtCita=(isset($_POST['txtCita']))?$_POST['txtCita']:"";
$txtPersonal=(isset($_POST['txtPersonal']))?$_POST['txtPersonal']:"";
$txtFecha=(isset($_POST['txtFecha']))?$_POST['txtFecha']:"";
$txtCosto=(isset($_POST['txtCosto']))?$_POST['txtCosto']:"";

$accion=(isset($_POST['accion']))?$_POST['accion']:"";

$error=array();

$accionAgregar="";
$accionModificar=$accionEliminar=$accionCancelar="disabled";
$mostrarModal=false;

include '../php/ConexionserviciosSA.php';


switch($accion){
    
    case "btnAgregar":
       $sentencia=$pdo->prepare("INSERT INTO servicios(TipoDeServicio,Cliente,Cita,Personal,Fecha,Costo)
        VALUES (:TipoDeServicio,:Cliente,:Cita,:Personal,:Fecha,:Costo) ");
       
        $sentencia->bindParam(':TipoDeServicio',$txtTipoDeServicio);
        $sentencia->bindParam(':Cliente',$txtCliente);
        $sentencia->bindParam(':Cita',$txtCita);
        $sentencia->bindParam(':Personal',$txtPersonal);
        $sentencia->bindParam(':Fecha',$txtFecha);
        $sentencia->bindParam(':Costo',$txtCosto);
        $sentencia->execute();
        
        header('Location: serviciosSA.php');
        break;
        case "btnModificar":
             $sentencia=$pdo->prepare(" UPDATE servicios SET
                                     TipoDeServicio=:TipoDeServicio,
                                     Cliente=:Cliente,
                                     Cita=:Cita,
                                     Personal=:Personal,
                                     Fecha=:Fecha,
                                     Costo=:Costo WHERE
                                     Servicio=:Servicio");
        
        $sentencia->bindParam(':TipoDeServicio',$txtTipoDeServicio);
        $sentencia->bindParam(':Cliente',$txtCliente);
        $sentencia->bindParam(':Cita',$txtCita);
        $sentencia->bindParam(':Personal',$txtPersonal);
        $sentencia->bindParam(':Fecha',$txtFecha);
        $sentencia->bindParam(':Costo',$txtCosto);
        $sentencia->bindParam(':Servicio',$txtServicio);
        $sentencia->execute();
        
        header('Location: serviciosSA.php');// redirecionamiento donde queremos que se valla la pagina
            //echo $txtID;
       // echo  "Presionaste btnModificar";
        break;
        case "btnEliminar":
             $sentencia=$pdo->prepare(" DELETE FROM servicios WHERE Servicio=:Servicio");
        $sentencia->bindParam(':Servicio',$txtServicio);
        $sentencia->execute();
        
        header('Location: serviciosSA.php');
       
        break;
        case "btnCancelar":
        header('Location: serviciosSA.php');
        break;
        case "Seleccionar":
            $accionAgregar="disabled";
            $accionModificar=$accionEliminar=$accionCancelar="";
            $mostrarModal=true;
                 
        $sentencia=$pdo->prepare(" SELECT * FROM `servicios` WHERE
                                     Servicio=:Servicio");
        $sentencia->bindParam(':Servicio',$txtServicio);
        $sentencia->execute();
        $servicios=$sentencia->fetch(PDO::FETCH_LAZY);
        
        $txtTipoDeServico=$servicios['TipoDeServicio'];
        $txtCliente=$servicios['Cliente'];
        $txtCita=$servicios['Cita'];
        $txtPersonal=$servicios['Personal'];
        $txtFecha=$servicios['Fecha'];
        $txtCosto=$servicios['Costo'];     
        break;
}
 
$sentencia= $pdo->prepare("SELECT * FROM `servicios` WHERE 1");
$sentencia->execute();
$listaservicios=$sentencia->fetchAll(PDO::FETCH_ASSOC);

//print_r($listaServicios);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Servicios</title>
    
    <link rel="stylesheet" href="assest/css/imagen.css">
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>

<body>
    <div>
        <form action="" method="post" enctype="multipart/form-data">

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Servicios</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
            <input type="hidden" required name="txtServicio" value="<?php echo $txtServicio;?>" placeholder="" id="txtServicio" require="">

<div class="form-group col-md-6">
<label for="">Tipo De Servicio(s):</label>
<input type="text" class="form-control" <?php echo (isset($error['TipoDeServicio']))?"is-invalid":"";?> name="txtTipoDeServicio" required value="<?php echo $txtTipoDeServicio;?>" placeholder="" id="txtApellidoPaterno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['TipoDeServicio']))?$error['TipoDeServicio']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Cliente:</label>
<input type="text" class="form-control" <?php echo (isset($error['Cliente']))?"is-invalid":"";?> name="txtCliente" required value="<?php echo $txtCliente;?>" placeholder="" id="txtCliente" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Cliente']))?$error['Cliente']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Cita:</label>
<input type="text" class="form-control" <?php echo (isset($error['Cita']))?"is-invalid":"";?> name="txtCita" required value="<?php echo $txtCita;?>" placeholder="" id="txtCita" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Cita']))?$error['Cita']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Personal:</label>
<input type="text" class="form-control" <?php echo (isset($error['Personal']))?"is-invalid":"";?> name="txtPersonal" required value="<?php echo $txtPersonal;?>" placeholder="" id="txtPersonal" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Personal']))?$error['Personal']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Fecha:</label>
<input type="text" class="form-control" <?php echo (isset($error['Fecha']))?"is-invalid":"";?> name="txtFecha" required value="<?php echo $txtFecha;?>" placeholder="" id="txtFecha" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Fecha']))?$error['Fecha']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Costo:</label>
<input type="text" class="form-control" <?php echo (isset($error['Costo']))?"is-invalid":"";?> name="txtCosto" value="<?php echo $txtCosto;?>" placeholder="" id="txtCosto" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Costo']))?$error['Costo']:"";?>
</div>
<br>
</div>
        </div>
      </div>
      <div class="modal-footer">
           <!-- creacion de botones  -->
<button value="btnAgregar" <?php echo $accionAgregar;?> class="btn btn-success" type="submit" name="accion">Agregar</button>
<button value="btnModificar" <?php echo $accionModificar;?> class="btn btn-warning" type="submit" name="accion">Modificar</button>
<button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" <?php echo $accionEliminar;?> class="btn btn-danger" type="submit" name="accion">Eliminar</button>
<button value="btnCancelar" <?php echo $accionCancelar;?> class="btn btn-primary" type="submit" name="accion">Cancelar</button>
      </div>
    </div>
  </div>
</div>

            <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Agegar Servicio
</button>
<br>
<br>
        </form>
        <div class="row">
            <table class="table table-hover table-borderred" bgcolor= "#ADBF87" border="2" cellpadding="1" cellspacing="1">
                <thead class="thead-dark">
                    <tr>
                       <th>Servicios</th>
                       <th>Tipo De Servicios</th>
                       <th>Cliente</th>
                       <th>Cita</th>
                       <th>Personal</th>
                       <th>Fecha</th>
                       <th>Costo</th>
                       <th>Acciones</th>
                    </tr>
                </thead>
                <?php foreach($listaservicios as $servicios){ ?>
                
                <tr>
                    <td><?php echo  $servicios['Servicio']; ?></td>
                    <td><?php echo  $servicios['TipoDeServicio']; ?></td>
                    <td><?php echo  $servicios['Cliente']; ?></td>
                    <td><?php echo  $servicios['Cita']; ?></td>
                    <td><?php echo  $servicios['Personal']; ?></td>
                    <td><?php echo  $servicios['Fecha']; ?></td>
                    <td><?php echo  $servicios['Costo']; ?></td>
                    <td>
                    <form action="" method="post">
                        
                        <input type="hidden" name="txtServicio" value="<?php echo $servicios['Servicio'];?>">
                        <input type="submit" value="Seleccionar" class="btn btn-info" name="accion">
                        <button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" type="submit" class="btn btn-danger" name="accion">Eliminar</button>
                        
                    </form>
                    </td>
                </tr>
                <?php } ?>
            </table>   
        </div>
      <?php if($mostrarModal){?>
      <script>
        $('#exampleModal').modal('show');
      </script>
      <?php }?>
      <script>
        function Confirmar(Mensaje){
            return (confirm(Mensaje))?true:false;
        }
      </script>
    </div>
</body>
</html>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio</title>
    <!--Zona de CSS-->
    <link rel="stylesheet" href="assest/css/bootstrap.min.css">
    <link rel="stylesheet" href="assest/css/font-awesome.min.css">
    <style>.rojo {color: #f00;}</style>
</head>

<body>
    <div class="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <a class="navbar-brand" href="index.php"><i class="fa fa-home fa-lg rojo"></i></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="login.html">Login <span class="sr-only">(actual)</span></a>
      </li>
      <!--
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li> -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Ventas
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Listar</a>
          <a class="dropdown-item" href="#">Exportar</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
    </li>
        <!--
      <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li>
        -->
      
     
     </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Acceso
        </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="nav-link" href="login.php">Login</a>
        <a class="nav-link" href="logout.php">logout</a>
                </div>
      </li>
      </ul>
    <!--
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
    -->
  </div>
</nav>
    </div> <!--./ Container menu -->
    
    <!--Zona de despliegue-->
    <br>
    <div class="container">
      <div class="row">
        <div class="col-sm-6 offset-sm-3">
            <div class="card">
  <div class="card-header">
    Login&nbsp;<i class="fa fa-key float-right"></i>
  </div>
  <div class="card-body">
    <form action="" method="post" id="frmLogin">
  <div class="form-group">
    <label for="usuario">Usuario</label>
    <div class="input-group">
      <div class="input-group-prepend">
        <div class="input-group-text"><i class="fa fa-user"></i></div>
        
         <input type="text" class="form-control" id="usuario" name="usuario" aria-describedby="usuario" placeholder="Usuario"></div>
    <small id="usuario" class="form-text text-muted">Nunca comparta sus datos con nadie.</small>
  </div>
      
  <div class="form-group">
    <label for="Password">Password</label>
     <div class="input-group">
      <div class="input-group-prepend">
        <div class="input-group-text"><i class="fa fa-lock"></i></div>
         <input type="password" name='password'  class="form-control" id="exampleInputPassword1" placeholder="Password">
      </div> 
  <button type="button" id="login" class="btn btn-primary btn-lg btn-block"><i class="fa fa-sign-in"></i>&nbsp;Entrar</button>
</form>
  </div>
  <div class="card-footer text-muted">
    Todos los derechos reservados este programa es publico queda prohibido su uso para fines distintos a los establecidos en el programa &copy
  </div>
        </div>
      </div>
  
</div>
    </div>
    
    <!--./Zona de despliegue-->
    <!--Zona de Js-->
    <script src="assest/js/jquery-3.3.1.min.js"></script>
    <script src="assest/js/bootstrap.min.js"></script>
    
    <script>
      $(function(){
        $('#login').on('click',function(){
         // console.log($('#frmLogin').serialize()); 
          $.ajax({
          type:'POST',
          url:'met_login.php',
          dataType:'json',
          data:$('#frmLogin').serialize(),
          success:function(datos){
            //TODO
            if(datos.exito){
            //console.log(datos); 
            location.href="index.php";
            }
          },
          error: function(e){
            console.log(e.responseText);
            }
           /*})
            .done(function(datos){
            //TODO
            if(datos.exito){
            //console.log(datos); 
            location.href="index.php";
            }
            else{
              alert('No autorizado');
              $('#usuario').select(); 
              
            }
            
            })
            .fail(function(e){
            console.log(e.responseText);
            });
            */
          });
        });
         });
      
      
    </script>
</body>

</html>
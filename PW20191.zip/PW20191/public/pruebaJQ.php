<!DOCTYPE html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prueba de JQuery</title>
    <link rel="stylesheet" href="assest/css/bootstrap.css"
</head>

<body>
    <div id="saludo">Mostrar</div>
    <hr>
    <button type="button" id="cambiaColor">Cambiar Color</button>&nbsp;|&nbsp;
    <button type="button" id="leerArchivo">Leer Archivo</button>&nbsp;|&nbsp;
     <button type="button" id="leerJSON">Leer JSON</button>
     <hr>
     <div class="container">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>sec</th>
                    <th>RFC</th>
                    <th>Nombre</th>
                    <th>Direccion</th>
                    <th>Telefono</th>
                    <th>Correo</th>
                </tr>
            </thead>
            <tbody id="clientes"></tbody>
        </table>
     </div>
    <!--zona de JS-->
    <script src="assest/js/jquery-3.3.1.min.js"></script>
    <script src="assest/js/bootstrap.min.js"></script>
    <script>
        $(function(){
            //deshabilita cache globalmente
            $.ajaxSetup({cache: false});
            //$('body').append($('<div>',{text:'Div Nuevo',class:'text-danger'}));
            //$('#saludo').click(function(){});
            $('#saludo').on('click',(function(){
                $(this).html('<b>¡¡Hola Mundo!!<b>');
                }));
            $('#cambiaColor').on('click',function(){
                $('#saludo').attr('class','text-info');
                $(this).hide();
                });
             //function leer archivo   
            $('#leerArchivo').on('click', function(){
                $.ajax({
                    type:'GET', //este es el method
                    url:'lectura.txt',
                    //cache: false,
                    //data: van los datos
                    dataType:'text' , //el tipo de datos a recibir
                    //succes:function(respuesta){},
                    //error:function(e){}
                })
                .done(function(respuesta){
                    alert(respuesta);
                    })
                .fail(function(e){
                    console.log(e.responseText);
                    });//fin de ajax
            });//fin de leer archivo
            //function leerJSON
            
            $('#leerJSON').on('click',function(){
               $.getJSON('Clientes.json', function(datos){
                       //console.log(datos);
                       $.each(datos.clientes,function(indice,cliente){
                        // ARMAR LA TABLA 
                            $('#clientes').append('<tr><td>'+(indice+1)+
                            '</td><td>'+cliente.rfc+
                            '</td><td>'+cliente.nombre+
                            '</td><td>'+cliente.direccion+
                            '</td><td>'+cliente.telefono+
                            '</td><td>'+cliente.correo+
                            '</td></tr>');
                        });
                }).fail(function(e){
                    console.log(e.responseText);
                    });
                    
                });
            });//fin carga de pagina
        //AJAX con JQuery, method: POST , GET
        //$.ajax({});   $.post  $.get $.getJSON
        
    </script>
</body>

</html>


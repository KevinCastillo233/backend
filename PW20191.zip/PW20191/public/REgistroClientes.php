<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<title> Inicio</title>
    <link rel="stylesheet"
          href="assest/CSS/bootstrap.min.css">
    <link rel="stylesheet"
          href="assest/CSS/font-awesome.min.css"
          
          
<body>
  <div class="container">
    
  </div>
  <div class= "row">
      <div class="col-sm-3">
      <img src="assest/img/logo.png" width="50" alt="logo">
      </div>
      <div class="col-sm-9">
        <h1>Empresas SA de CV</h1>
      </div>
  </div>
  <hr>
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-light bg-info rounded">
  <a class="navbar-brand" href="index.html"><i class="fa fa-home fa-lg"></i></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="clientes.html">Clientes <span class="sr-only">(current)</span></a>
      </li>
      <!--
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>-->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          ventas
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Listar</a>
          <a class="dropdown-item" href="#">Exportar</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      
      <!--<li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li>-->
      
      <span class="nav-item mr-2">
        <a class="nav-link active" href="login.html">login</a>
      </span>
      
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link active" href="login.html">login</a>
      </li>
    </ul>

    <!--<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>-->
  </div>
</nav>
</div>
  <br>
  <div class="container">
    <div class="row">
      <div class="col-sm-6 offset-sm-3">
        <div class="card bg-light">
  <div class="card-header">
    Registro de clientes&nbsp<i class="fa fa-book ml-auto float-right"></i>
  </div>
  <div class="card-body">
    <form action="" method="get">
            
    <div class="form-group">
    <label for="nombre">nombre</label>
    <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-user-circle-o"></i> </div>
    </div>
    <input type="text" class="form-control" id="nombre" placeholder="nombre">
    </div>
    </div>
  <div class="form-group">
    <label for="RFC">RFC</label>
    <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-id-card-o""></i> </div>
    </div>
    <input type="text" class="form-control" id="R.F.C" placeholder="R.F.C">
    </div>
    </div>
    
    
    <div class="form-group">
    <label for="direc ion">direccion</label>
    <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-eject"></i> </div>
    </div>
    <input type="text" class="form-control" id="direccion" placeholder="direccion">
    </div>
    </div>
    
     <div class="form-group">
    <label for="correoelectronico">correo electronico</label>
    <div class="input-group mb-2 mr-sm-2">
    <div class="input-group-prepend">
      <div class="input-group-text"><i class="fa fa-envelope"></i> </div>
    </div>
    <input type="text" class="form-control" id="correoelectronico" placeholder="correoelectronico">
    </div>
    </div>
    
    
  
  <button type="submit" class="btn btn-primary btn-lg btn-block"><i class="fa fa-book"></i>&nbsp;Registrar cliente</button>

  </div>
  <div class="card-footer text-muted">
    Este programa es público, ajeno a cualquier partido político. Queda prohibido el uso para fines distintos a los establecidos en el programa &copy 
  </div>
</div>
      </div>
    </div>
  </div>

          </div>     
     
     
     <!--zona de js-->
     <script src="assest/JS/jquery-3.0.0.min.js"> </script>
     <script src="assest/JS/bootstrap.min.js"> </script>
    
</body>

</html>


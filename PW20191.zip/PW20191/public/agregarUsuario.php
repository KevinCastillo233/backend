<?php
//script para hacer uso del metodo agregar Usuario
include '../php/UsuariosController.php';

foreach($_POST as $key=>$value){
  $$key=$value;  
}
//$id=$_POST['usuario'];
//echo $usuario;

#tratamiento especial para password
$password=sha1($password);

#tratamiento especial para fotos
$foto=addslashes(file_get_contents($_FILES['foto']['tmp_name']));

$usuarios=new Usuarios;
$agregarUsuario=$usuarios->agregarUsuario($usuario,$nombre,$email,$password,$rol,$foto);
//echo $agregarUsuario;
echo json_encode ($agregarUsuario);

?> <!--
<pre>
    <?php echo var_dump($_POST);?>
    <hr>
    <?php echo var_dump($_FILES);?>
</pre  --> 
<?php
//sin modal
$txtID=(isset($_POST['txtID']))?$_POST['txtID']:"";
$txtNombre=(isset($_POST['txtNombre']))?$_POST['txtNombre']:"";
$txtApellidoPaterno=(isset($_POST['txtApellidoPaterno']))?$_POST['txtApellidoPaterno']:"";
$txtApellidoMaterno=(isset($_POST['txtApellidoMaterno']))?$_POST['txtApellidoMaterno']:"";
$txtDireccion=(isset($_POST['txtDireccion']))?$_POST['txtDireccion']:"";
$txtTelefono=(isset($_POST['txtTelefono']))?$_POST['txtTelefono']:"";
$txtEmail=(isset($_POST['txtEmail']))?$_POST['txtEmail']:"";

$accion=(isset($_POST['accion']))?$_POST['accion']:"";

$error=array();

$accionAgregar="";
$accionModificar=$accionEliminar=$accionCancelar="disabled";
$mostrarModal=false;

include ("../php/ConexionclientesSA.php");
//include ("ConexionserviciosSA.php");

switch($accion){
    
    case "btnAgregar":
        
        if($txtNombre==""){
        $error['Nombre']="Escribe El Nombre";
      }
      if($txtApellidoPaterno==""){
        $error['ApellidoPaterno']="Escribe Tu Apellido Paterno";
      }
      if($txtApellidoMaterno==""){
        $error['ApellidoPaterno']="Escribe Tu Apellido Materno";
      }
      if($txtDireccion==""){
        $error['Direccion']="Escribe Tu Direccion";
      }
      if($txtTelefono==""){
        $error['Telefono']="Pon Tu Numero Telefonico";
      }
      if($txtEmail==""){
        $error['Email']="Escribe Tu Email";
      }
      if(count($error)>0){
        $mostrarModal=true;
       
      }
        
        $sentencia=$pdo->prepare("INSERT INTO clientes(Nombre,ApellidoPaterno,ApellidoMaterno,Direccion,Telefono,Email)
        VALUES (:Nombre,:ApellidoPaterno,:ApellidoMaterno,:Direccion,:Telefono,:Email) ");
        
        $sentencia->bindParam(':Nombre',$txtNombre);
        $sentencia->bindParam(':ApellidoPaterno',$txtApellidoPaterno);
        $sentencia->bindParam(':ApellidoMaterno',$txtApellidoMaterno);
        $sentencia->bindParam(':Direccion',$txtDireccion);
        $sentencia->bindParam(':Telefono',$txtTelefono);
        $sentencia->bindParam(':Email',$txtEmail);
        $sentencia->execute();
        //echo $txtID;
       // echo  "Presionaste btnAgregar";
        header('Location: ClientesSA.php');
        break;
        case "btnModificar":
             $sentencia=$pdo->prepare(" UPDATE clientes SET
                                     Nombre=:Nombre,
                                     ApellidoPaterno=:ApellidoPaterno,
                                     ApellidoMaterno=:ApellidoMaterno,
                                     Direccion=:Direccion,
                                     Telefono=:Telefono,
                                     Email=:Email WHERE
                                     ID=:ID");
        
        $sentencia->bindParam(':Nombre',$txtNombre);
        $sentencia->bindParam(':ApellidoPaterno',$txtApellidoPaterno);
        $sentencia->bindParam(':ApellidoMaterno',$txtApellidoMaterno);
        $sentencia->bindParam(':Direccion',$txtDireccion);
        $sentencia->bindParam(':Telefono',$txtTelefono);
        $sentencia->bindParam(':Email',$txtEmail);
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        
        header('Location: ClientesSA.php');// redirecionamiento donde queremos que se valla la pagina
            //echo $txtID;
       // echo  "Presionaste btnModificar";
        break;
        case "btnEliminar":
             $sentencia=$pdo->prepare(" DELETE FROM clientes WHERE ID=:ID");
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        
        header('Location: ClientesSA.php');
            //echo $txtID;
       // echo  "Presionaste btnEliminar";
        break;
        case "btnCancelar":
            //echo $txtID;
       // echo  "Presionaste btnCancelar";
        header('Location: ClientesSA.php');
        break;
        case "Seleccionar":
            $accionAgregar="disabled";
            $accionModificar=$accionEliminar=$accionCancelar="";
            $mostrarModal=true;
                 
        $sentencia=$pdo->prepare(" SELECT * FROM `clientes` WHERE
                                     ID=:ID");
        $sentencia->bindParam(':ID',$txtID);
        $sentencia->execute();
        $clientes=$sentencia->fetch(PDO::FETCH_LAZY);
        
        $txtNombre=$clientes['Nombre'];
        $txtApellidoPaterno=$clientes['ApellidoPaterno'];
        $txtApellidoMaterno=$clientes['ApellidoMaterno'];
        $txtDireccion=$clientes['Direccion'];
        $txtTelefono=$clientes['Telefono'];
        $txtEmail=$clientes['Email'];
        
                 
        break;
    
        
    
}
 
$sentencia= $pdo->prepare("SELECT * FROM `clientes` WHERE 1");
$sentencia->execute();
$listaclientes=$sentencia->fetchAll(PDO::FETCH_ASSOC);

//print_r($listaclientes);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro De Clientes</title>
    
    <link rel="stylesheet" href="assest/css/imagen.css">
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>

<body>
    <div>
        <form action="" method="post" enctype="multipart/form-data">

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Clientes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
            <input type="hidden" required name="txtID" value="<?php echo $txtID;?>" placeholder="" id="txtID" require="">

<div class="form-group col-md-6">
<label for="">Nombre(s):</label>
<input type="text" class="form-control" <?php echo (isset($error['Nombre']))?"is-invalid":"";?> name="txtNombre" required value="<?php echo $txtNombre;?>" placeholder="" id="txtNombre" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Nombre']))?$error['Nombre']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Apellido Paterno:</label>
<input type="text" class="form-control" <?php echo (isset($error['ApellidoPaterno']))?"is-invalid":"";?> name="txtApellidoPaterno" required value="<?php echo $txtApellidoPaterno;?>" placeholder="" id="txtApellidoPaterno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['ApellidoPaterno']))?$error['ApellidoPaterno']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Apellido Materno:</label>
<input type="text" class="form-control" <?php echo (isset($error['ApellidoMaterno']))?"is-invalid":"";?> name="txtApellidoMaterno" required value="<?php echo $txtApellidoMaterno;?>" placeholder="" id="txtApellidoMaterno" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['ApellidoMaterno']))?$error['ApellidoMaterno']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Direccion:</label>
<input type="text" class="form-control" <?php echo (isset($error['Direccion']))?"is-invalid":"";?> name="txtDireccion" required value="<?php echo $txtDireccion;?>" placeholder="" id="txtDireccion" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Direccion']))?$error['Direccion']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Telefono:</label>
<input type="text" class="form-control" <?php echo (isset($error['Telefono']))?"is-invalid":"";?> name="txtTelefono" required value="<?php echo $txtTelefono;?>" placeholder="" id="txtTelefono" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Telefono']))?$error['Telefono']:"";?>
</div>
<br>
</div>

<div class="form-group col-md-6">
<label for="">Email:</label>
<input type="email" class="form-control" <?php echo (isset($error['Email']))?"is-invalid":"";?> name="txtEmail" value="<?php echo $txtEmail;?>" placeholder="" id="txtEmail" require="">
<div class="invalid-feedback">
  <?php echo (isset($error['Email']))?$error['Email']:"";?>
</div>
<br>
</div>
        </div>
      </div>
      <div class="modal-footer">
           <!-- creacion de botones  -->
<button value="btnAgregar" <?php echo $accionAgregar;?> class="btn btn-success" type="submit" name="accion">Agregar</button>
<button value="btnModificar" <?php echo $accionModificar;?> class="btn btn-warning" type="submit" name="accion">Modificar</button>
<button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" <?php echo $accionEliminar;?> class="btn btn-danger" type="submit" name="accion">Eliminar</button>
<button value="btnCancelar" <?php echo $accionCancelar;?> class="btn btn-primary" type="submit" name="accion">Cancelar</button>
      </div>
    </div>
  </div>
</div>

            <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Agegar Cliente
</button>
<br>
<br>
        </form>
        <div class="row">
            <table class="table table-hover table-borderred" bgcolor= "#ADBF87" border="2" cellpadding="1" cellspacing="1">
                <thead class="thead-dark">
                    <tr>
                       <th>ID</th>
                       <th>Nombre(s)</th>
                       <th>Apellido Paterno</th>
                       <th>Apellido Materno</th>
                       <th>Direccion</th>
                       <th>Telefono</th>
                       <th>Email</th>
                       <th>Acciones</th>
                    </tr>
                </thead>
                <?php foreach($listaclientes as $clientes){ ?>
                
                <tr>
                    <td><?php echo  $clientes['ID']; ?></td>
                    <td><?php echo  $clientes['Nombre']; ?></td>
                    <td><?php echo  $clientes['ApellidoPaterno']; ?></td>
                    <td><?php echo  $clientes['ApellidoMaterno']; ?></td>
                    <td><?php echo  $clientes['Direccion']; ?></td>
                    <td><?php echo  $clientes['Telefono']; ?></td>
                    <td><?php echo  $clientes['Email']; ?></td>
                    <td>
                    <form action="" method="post">
                        
                        <input type="hidden" name="txtID" value="<?php echo $clientes['ID'];?>">
                        <input type="submit" value="Seleccionar" class="btn btn-info" name="accion">
                        <button value="btnEliminar" onclick="return Confirmar('¿Estas Seguro De Borrar El Registro?');" type="submit" class="btn btn-danger" name="accion">Eliminar</button>
                        
                    </form>
                    </td>
                </tr>
                <?php } ?>
            </table>   
        </div>
      <?php if($mostrarModal){?>
      <script>
        $('#exampleModal').modal('show');
      </script>
      <?php }?>
      <script>
        function Confirmar(Mensaje){
            return (confirm(Mensaje))?true:false;
        }
      </script>
    </div>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Login</title>
    <link rel="stylesheet" href="assest/css/imagen.css">
    <link rel="stylesheet" href="assest/css/bootstrap.min.css">
    <!--fuente de iconos-->
    <link rel="stylesheet" href="assest/css/font-awesome.min.css">
    <!--<link rel="stylesheet" type="text/css" href="assest/css/estilo-login.css"/>-->
</head>
 
<body>
    
    <?php
        session_start();
        // Se comprueba si ya se habia iniciado la sesion.
        if(isset($_SESSION['id'])){
            header("Location:pagina1.php");
        }
    ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-sm-4 offset-sm-3">
                <br>
                <br>
                <br>
                <br>
                <div class="card">
                  <div class="card-header">
                    <!--ENCABEZADO-->
                    
                    LOGIN&nbsp;<i class=""></i>
                  </div>
                  <div class="card-body">
                   <form>
    <section>
        <div id="formulario_login">
        	<form action="controlador/login.php" method="POST">
                <div class="campoFormulario">
                    <label for="usuario">Usuario:</label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-user"></i></div>
                    <input type='text' name="usuario" maxlength="15"/>
                </div>
                <div class="campoFormulario">
                    <label for="password">Contraseña:</label>
                    <div class="input-group">
                       <div class="input-group-prepend">
                           <div class="input-group-text"><i class="fa fa-lock"></i></div>
                    <input type='password' name="password" maxlength="20"/>
                </div>
                <div class="botonFormulario">
                    <input type="submit" id="login" name="login" value="Entrar">
                </div>  
                <div id="enlace_registro">
                    <a href="formulario_registro.php"> Registrarse </a>
                </div>
            </form> 
               
            <?php
                if(!empty($_GET['error'])) {
            ?>
                <p class="errorUsuario">Usuario o pasword incorrectos</p>
            <?php } ?>
        </div>
    </section>
</body>
</html>

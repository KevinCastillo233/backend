<?php
include '../php/UsuariosController.php';
$usuarios=new Usuarios;
$listarUsuarios=$usuarios->listarUsuarios();
if($listarUsuarios['exito'])
{
    // fopen crear/usar el archivo
    // frwite escribir en el archivo
    // fclose cerrar el archivo
    $archivo_csv=fopen('../archivos/usuarios.csv'.time().'.cvs','w+');
    fwrite($archivo_csv, "ID_USUARIO, NOMBRE,CORREO,ROL\n");
    foreach($listarUsuarios['usuarios'] as $key => $usuario){
        fwrite($archivo_csv,$usuario['id'].','.
        $usuario['nombre'].','.
        $usuario['correo'].','.
        $usuario['rol']."\n");
        
    }
    fclose($archivo_csv);
}
echo json_encode($listarUsuarios['exito']);
?>
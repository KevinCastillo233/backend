<?php
include '../php/ClienteController.php';
$clientes=new Clientes;
$listarClientes=$clientes->listarClientes();
foreach($listarClientes as $llave=>$valor){
    echo $llave.','.$valor.'<br>';
}
?>
<!--
<pre>
    
    <?php //echo var_dump($listarClientes);
    ?>
</pre>
-->
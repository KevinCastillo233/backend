<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Tarea</title>
	<link rel="stylesheet" href="assest/css/bootstrap.min.css"
</head>

<body>
   <br>
	<div id="saludo" onclick="mostrar();">Mostrar</div>
         <hr>
    <form action="" method="get" onsubmit="return validar();">
        <input type="text" placeholder="Nombre" id="nombre" name="nombre">
        <br>
        <button type="submit">Enviar</button>
   
    <hr>
    
   <div>TABLAS</div>
	<hr>
	<input type="text" placeholder="Numero de renglones" id="ren" name="ren">
	<input type="text" placeholder="Numero de columnas" id="col" name="col">
    <br/>
    <br>
    <button type="button" onclick="crearTabla(ren, col)">Crear Tabla</button>&nbsp;
	 <button type="button" onclick="LeerArchivo()">Leer Archivo</button>
    <hr/>
	<div id="tabla" class="container"></div>
	
	<script src="assest/js/jquery.js"></script>
    <script src="assest/js/bootstrap.min.js"></script>
	<script>
		function validar()
{
    var sNombre=document.getElementById("nombre").value;
    if(sNombre===null || /^\S+ $/.test(sNombre)||sNombre.length===0)
    {
        alert("No cumple requisitos");
        return false;
    }
    return true;
    }
   
        function mostrar()
        {
            //alert("Hola Mundo!!!");
            divSaludo=document.getElementById("saludo");
            //console.log(divSaludo);
            divSaludo.innerHTML="Hola Mundo";
            divSaludo.style.color="#f00";
        }
        //fuction creaDiv
        function creaDiv()
        {
         var nuevoDiv=document.createElement("div");
         var nuevoSaludo=document.createTextNode("Saludo de Nuevo");
         /* <div>Saludo de nuevo</div> */
         nuevoDiv.appendChild(nuevoSaludo);
         document.getElementsByTagName("body") [0].appendChild(nuevoDiv);
        }
		
		function crearTabla(nRen, nCol)
		{
			nRen = (nRen <= 0 || nRen === undefined ? 1 : nRen);
			nCol = (nCol <= 0 || nCol === undefined ? 1 : nCol);
			
			nRen = document.getElementById("ren").value;
			nCol = document.getElementById("col").value;
			
			//evitar duplicidad
			var oContenedor = document.getElementById("tabla");
			oContenedor.innerHTML = "";
			
			//inicio de creacion de tabla
			var oTabla = document.createElement("table");
			oTabla.setAttribute("class", "table table-striped table-hover");
			var oThead = document.createElement("thead");
			var oTbody = document.createElement("tbody");
			
			//var oTfoot = document.createElement("tfoot");
			var renglon = document.createElement("tr");
			var tds = document.createElement("td");

			//armar el encabezado
			var ths = document.createElement("th");
			var texto = document.createTextNode("Sec.");
			ths.appendChild(texto);
			renglon.appendChild(ths);

			for (i = 1; i <= nCol; i++)
			{
				var titulo = document.createTextNode(i);
				ths = document.createElement("th");
				ths.appendChild(titulo);
				renglon.appendChild(ths);
			} //fin de for encabezado
			oThead.appendChild(renglon);
			oTabla.appendChild(oThead);
        
			for(i = 1;i <= nRen; i++)
			{
				renglon= document.createElement("tr");
				var encabezadoRen = document.createElement("th");
				inicioRen = document.createTextNode(i);
				encabezadoRen.appendChild(inicioRen);
				renglon.appendChild(encabezadoRen);  
				for (j = 1; j <= nCol; j++)
				{
					titulo2 = document.createTextNode(i+","+j);
					tds = document.createElement("td");
					tds.appendChild(titulo2);
					renglon.appendChild(tds);
				} 
				oTbody.appendChild(renglon);
			}
			oTabla.appendChild(oTbody);
			oContenedor.appendChild(oTabla);
			
      }
	</script>
	
	<script>
		//maquina AJAX
		function LeerArchivo()
		{
			//crear el objeto
			xhrLeer=(window.XMLHttpRequest)?
			new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
			//validar estados
			xhrLeer.onreadystatechange= function()
			{
				if(xhrLeer.readyState==4 && xhrLeer.status==200)
				{
					var respuesta=xhrLeer.responseText;
					document.getElementById("saludo").innerHTML=respuesta;
				}//fin de if readyState/status
			};//fin de onreadystatechange
			xhrLeer.open("GET","lectura.txt",true);
			xhrLeer.send(null);
		}//fin de function Leer Archivo
	</script>
</body>

</html>
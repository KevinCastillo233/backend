<?php
//script para hacer uso del metodo agregar Usuario
include '../php/UsuariosController.php';

$id=$_POST['id'];


$usuarios=new Usuarios;
$buscarUsuario=$usuarios->agregarUsuario($id);

//echo $agregarUsuario;
echo $id;
echo json_encode ($buscarUsuario);

?> 
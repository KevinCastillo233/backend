<?php
/*
 * script para conectar a MySQL
 * con funciones nativas
 */
$conn=mysqli_connect('localhost','root','','ventas') or die('Error de conexion');
$sqlUsuarios='SELECT id,nombre,correo,rol FROM usuarios';
$qryUsuarios=mysqli_query($conn,$sqlUsuarios)or die('Error en consulta');
//tema de tabla
?>
<table>
   <tr><td>ID</td><td>Nombre</td><td>Correo</td><td>Rol</td></tr>
   </table>

<?php
if(mysqli_num_rows($qryUsuarios))
{
    

while($renglon= mysqli_fetch_array($qryUsuarios)){
    ?>
     <tr><td><?php echo$renglon['id']; ?></td>
     <td><?php echo $renglon['nombre']; ?></td>
     <td><?php echo $renglon['correo']; ?></td>
     <td><?php echo $renglon['rol']; ?></td></tr>
     <?php
     
    //echo'Nombre'.$renglon['nombre'].' correo'.$renglon['correo'];
    
    }//fin de while 
}// fin de if
else
{
    ?>
    <tr><td colspan="4">No hay registros</td></tr>
    <?php
}
?>

<pre>
    <?php //echo var_dump($sqlUsuarios); ?>
</pre>